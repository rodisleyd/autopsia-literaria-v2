
export interface NarrativeFramework {
  name: string;
  stages: {
    label: string;
    description: string;
    foundInText: boolean;
    evidence: string;
  }[];
}

export interface Character {
  name: string;
  role: string;
  arc: string;
  strengths: string[];
  weaknesses: string[];
  impact: string;
}

export interface ToneAnalysis {
  lexicalMarkers: string[];
  sentenceStructure: string;
  atmosphericElements: string[];
}

export interface AnalysisResult {
  id: string;
  timestamp: number;
  overview: {
    title: string;
    premise: string;
    centralPlot: string;
    mainThemes: string[];
  };
  score: number;
  scoreJustification: {
    strengths: string[];
    weaknesses: string[];
  };
  metrics: {
    intensity: 'Lento' | 'Médio' | 'Rápido';
    intensityDescription: string;
    rhythmScore: number;
    rhythmDescription: string;
    tone: string;
    toneDescription: string;
    toneAnalysis: ToneAnalysis;
    complexity: 'Simples' | 'Moderada' | 'Complexa';
    complexityDescription: string;
  };
  genre: {
    primary: string;
    subgenres: string[];
  };
  narrativeStructures: {
    herosJourney: NarrativeFramework;
    saveTheCat: NarrativeFramework;
    storyCircle: NarrativeFramework;
  };
  characters: Character[];
  languageAndDialog: {
    vocabulary: string;
    subtextEfficiency: number;
    dialogueQuality: string;
    expositionCheck: string;
  };
  worldBuilding: {
    description: string;
    coherence: number;
  };
  rewritingTips: {
    section: string;
    suggestion: string;
  }[];
}

export enum AppStatus {
  IDLE = 'IDLE',
  UPLOADING = 'UPLOADING',
  ANALYZING = 'ANALYZING',
  COMPLETED = 'COMPLETED',
  HISTORY = 'HISTORY',
  ERROR = 'ERROR'
}
