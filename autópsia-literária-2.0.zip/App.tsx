
import React, { useState, useEffect } from 'react';
import { Layout } from './components/Layout';
import { FileUpload } from './components/FileUpload';
import { Dashboard } from './components/Dashboard';
import { HistoryList } from './components/HistoryList';
import { analyzeLiteraryText } from './services/geminiService';
import { AnalysisResult, AppStatus } from './types';

const STORAGE_KEY = 'autopsia_literaria_history';

const App: React.FC = () => {
  const [status, setStatus] = useState<AppStatus>(AppStatus.IDLE);
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const [history, setHistory] = useState<AnalysisResult[]>([]);

  // Load history from localStorage on mount
  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        setHistory(JSON.parse(saved));
      } catch (e) {
        console.error("Failed to load history", e);
      }
    }
  }, []);

  // Save history to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(history));
  }, [history]);

  const handleTextUpload = async (text: string) => {
    setStatus(AppStatus.ANALYZING);
    try {
      const result = await analyzeLiteraryText(text);
      
      // Add unique ID and timestamp for history tracking
      const finalResult: AnalysisResult = {
        ...result,
        id: Math.random().toString(36).substr(2, 9),
        timestamp: Date.now()
      };

      setAnalysisResult(finalResult);
      setHistory(prev => [finalResult, ...prev]);
      setStatus(AppStatus.COMPLETED);
    } catch (error) {
      console.error("Analysis failed:", error);
      setStatus(AppStatus.ERROR);
    }
  };

  const handleReset = () => {
    setAnalysisResult(null);
    setStatus(AppStatus.IDLE);
  };

  const handleSelectFromHistory = (result: AnalysisResult) => {
    setAnalysisResult(result);
    setStatus(AppStatus.COMPLETED);
  };

  const handleDeleteFromHistory = (id: string) => {
    setHistory(prev => prev.filter(item => item.id !== id));
  };

  const navigateToHistory = () => {
    setStatus(AppStatus.HISTORY);
  };

  return (
    <Layout 
      onNavigateHome={handleReset} 
      onNavigateHistory={navigateToHistory}
    >
      {status === AppStatus.IDLE || status === AppStatus.ANALYZING ? (
        <div className="flex flex-col items-center py-12 md:py-20">
          <div className="text-center mb-12 max-w-2xl animate-in fade-in slide-in-from-top-4 duration-1000">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6 font-serif">
              A ciência por trás da <span className="text-violet italic">sua história.</span>
            </h2>
            <p className="text-lg text-charcoal">
              Submeta seu manuscrito para uma autópsia textual completa. Arcos narrativos, ritmo, subtexto e perfis de personagens dissecados por IA avançada.
            </p>
          </div>
          
          <FileUpload 
            onUpload={handleTextUpload} 
            isLoading={status === AppStatus.ANALYZING} 
          />
        </div>
      ) : status === AppStatus.COMPLETED && analysisResult ? (
        <Dashboard data={analysisResult} onReset={handleReset} />
      ) : status === AppStatus.HISTORY ? (
        <HistoryList 
          history={history} 
          onSelect={handleSelectFromHistory} 
          onDelete={handleDeleteFromHistory}
          onBack={handleReset}
        />
      ) : status === AppStatus.ERROR ? (
        <div className="flex flex-col items-center justify-center py-20 text-center">
          <div className="bg-red-500/10 p-6 rounded-2xl border border-red-500/20 max-w-md">
            <h3 className="text-xl font-bold text-red-400 mb-2">Erro na Autópsia</h3>
            <p className="text-lightgrey mb-6">Não conseguimos processar o seu texto. Certifique-se de que o manuscrito não é muito curto ou contém caracteres inválidos.</p>
            <button 
              onClick={handleReset}
              className="px-6 py-2 bg-charcoal/20 border border-charcoal rounded-lg text-white hover:bg-violet transition-all"
            >
              Tentar Novamente
            </button>
          </div>
        </div>
      ) : null}
    </Layout>
  );
};

export default App;
