
import React from 'react';

interface LayoutProps {
  children: React.ReactNode;
  onNavigateHome: () => void;
  onNavigateHistory: () => void;
}

export const Layout: React.FC<LayoutProps> = ({ children, onNavigateHome, onNavigateHistory }) => {
  return (
    <div className="min-h-screen flex flex-col bg-midnight text-lightgrey">
      <header className="border-b border-charcoal bg-midnight/80 backdrop-blur-md sticky top-0 z-50 no-print">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div 
            className="flex items-center gap-3 cursor-pointer group"
            onClick={onNavigateHome}
          >
            <div className="w-10 h-10 bg-gradient-to-br from-violet to-teal rounded-lg flex items-center justify-center font-bold text-white shadow-lg shadow-violet/20 group-hover:scale-110 transition-transform">
              AL
            </div>
            <h1 className="text-xl font-bold tracking-tight text-white font-serif italic">
              Autópsia Literária <span className="text-violet">2.0</span>
            </h1>
          </div>
          <div className="hidden md:flex gap-6 text-sm font-medium">
            <button 
              onClick={onNavigateHome}
              className="hover:text-violet transition-colors"
            >
              Início
            </button>
            <button 
              onClick={onNavigateHistory}
              className="hover:text-violet transition-colors"
            >
              Histórico
            </button>
          </div>
        </div>
      </header>
      
      <main className="flex-1 w-full max-w-7xl mx-auto px-4 py-8">
        {children}
      </main>

      <footer className="border-t border-charcoal py-8 mt-auto bg-midnight/50 no-print">
        <div className="max-w-7xl mx-auto px-4 text-center text-charcoal text-sm">
          <p>© 2024 Autópsia Literária 2.0 - DevArchitect AI. Todos os direitos reservados.</p>
        </div>
      </footer>
    </div>
  );
};
