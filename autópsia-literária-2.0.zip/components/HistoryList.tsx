
import React from 'react';
import { AnalysisResult } from '../types';

interface HistoryListProps {
  history: AnalysisResult[];
  onSelect: (result: AnalysisResult) => void;
  onDelete: (id: string) => void;
  onBack: () => void;
}

export const HistoryList: React.FC<HistoryListProps> = ({ history, onSelect, onDelete, onBack }) => {
  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-500 max-w-4xl mx-auto w-full">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h2 className="text-3xl font-bold text-white font-serif">Histórico de Autópsias</h2>
          <p className="text-charcoal mt-1">Recupere análises realizadas anteriormente.</p>
        </div>
        <button 
          onClick={onBack}
          className="px-4 py-2 text-sm border border-charcoal rounded-lg text-charcoal hover:text-white hover:border-violet transition-all"
        >
          Voltar ao Início
        </button>
      </div>

      {history.length === 0 ? (
        <div className="bg-charcoal/5 border border-dashed border-charcoal/30 rounded-2xl p-12 text-center">
          <p className="text-charcoal">Nenhuma análise salva no histórico ainda.</p>
        </div>
      ) : (
        <div className="grid gap-4">
          {history.sort((a, b) => b.timestamp - a.timestamp).map((item) => (
            <div 
              key={item.id}
              className="bg-charcoal/10 border border-charcoal/30 rounded-xl p-5 hover:border-violet/50 transition-all group flex items-center justify-between"
            >
              <div 
                className="flex-1 cursor-pointer"
                onClick={() => onSelect(item)}
              >
                <div className="flex items-center gap-3 mb-1">
                  <h3 className="font-bold text-white group-hover:text-violet transition-colors">{item.overview.title}</h3>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-violet/20 text-violet font-bold uppercase tracking-wider">
                    {item.genre.primary}
                  </span>
                </div>
                <div className="flex items-center gap-4 text-xs text-charcoal">
                  <span>{new Date(item.timestamp).toLocaleDateString('pt-BR')} às {new Date(item.timestamp).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}</span>
                  <span className="flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-violet"></span>
                    Nota {item.score}/10
                  </span>
                </div>
              </div>
              
              <div className="flex items-center gap-2">
                <button 
                  onClick={() => onSelect(item)}
                  className="p-2 rounded-lg bg-violet/10 text-violet hover:bg-violet hover:text-white transition-all text-xs font-bold"
                >
                  ABRIR
                </button>
                <button 
                  onClick={() => onDelete(item.id)}
                  className="p-2 rounded-lg bg-red-500/10 text-red-400 hover:bg-red-500 hover:text-white transition-all"
                  title="Excluir do histórico"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                  </svg>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
