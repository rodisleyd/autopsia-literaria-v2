
import React, { useState, useRef } from 'react';
import { ICONS } from '../constants';

interface FileUploadProps {
  onUpload: (text: string) => void;
  isLoading: boolean;
}

export const FileUpload: React.FC<FileUploadProps> = ({ onUpload, isLoading }) => {
  const [dragActive, setDragActive] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0]);
    }
  };

  const handleFile = async (file: File) => {
    if (file.type !== "text/plain" && !file.name.endsWith('.txt')) {
      setError("Por favor, envie apenas arquivos de texto (.txt) por enquanto.");
      return;
    }
    setError(null);
    const text = await file.text();
    onUpload(text);
  };

  return (
    <div className="max-w-3xl mx-auto w-full">
      <div 
        className={`relative border-2 border-dashed rounded-2xl p-12 transition-all duration-300 flex flex-col items-center justify-center gap-4 ${
          dragActive ? 'border-violet bg-violet/5 scale-[1.02]' : 'border-charcoal hover:border-violet/50'
        } ${isLoading ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}`}
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
        onClick={() => !isLoading && fileInputRef.current?.click()}
      >
        <input 
          ref={fileInputRef}
          type="file" 
          className="hidden" 
          accept=".txt" 
          onChange={handleChange}
          disabled={isLoading}
        />
        
        <div className={`p-4 rounded-full bg-charcoal/30 text-violet ${dragActive ? 'scale-110' : ''} transition-transform`}>
          <ICONS.Upload />
        </div>
        
        <div className="text-center">
          <p className="text-xl font-semibold text-white">
            {isLoading ? "Processando Obra..." : "Arraste seu manuscrito aqui"}
          </p>
          <p className="text-charcoal mt-2">ou clique para selecionar um arquivo .txt</p>
        </div>

        {error && (
          <div className="mt-4 p-3 bg-red-500/10 border border-red-500/20 rounded-lg text-red-400 text-sm flex items-center gap-2">
            <ICONS.Warning /> {error}
          </div>
        )}

        {isLoading && (
          <div className="absolute inset-0 flex items-center justify-center bg-midnight/80 rounded-2xl">
            <div className="flex flex-col items-center gap-4">
              <div className="w-12 h-12 border-4 border-violet border-t-transparent rounded-full animate-spin"></div>
              <p className="text-violet font-medium animate-pulse">Iniciando Autópsia Literária...</p>
            </div>
          </div>
        )}
      </div>
      
      <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-charcoal">
        <div className="bg-charcoal/10 p-4 rounded-xl border border-charcoal/20">
          <h4 className="font-semibold text-lightgrey mb-1">Análise Estrutural</h4>
          <p>Mapeamento automático de arcos clássicos como a Jornada do Herói.</p>
        </div>
        <div className="bg-charcoal/10 p-4 rounded-xl border border-charcoal/20">
          <h4 className="font-semibold text-lightgrey mb-1">Ritmo & Tom</h4>
          <p>Identificação de problemas de pacing e inconsistências tonais.</p>
        </div>
        <div className="bg-charcoal/10 p-4 rounded-xl border border-charcoal/20">
          <h4 className="font-semibold text-lightgrey mb-1">Diálogos</h4>
          <p>Detecção de subtexto e exposição excessiva (Info-dumping).</p>
        </div>
      </div>
    </div>
  );
};
